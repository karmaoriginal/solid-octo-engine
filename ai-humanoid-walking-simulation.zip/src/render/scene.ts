import * as THREE from "three";
import { CONFIG } from "../config";
import { BODY_SPECS, RENDER_BODIES } from "../sim/spec";
import { terrainY, type Piece } from "../sim/terrain";

/**
 * ============================================================
 *  ESCENA 3D (three.js) — solo dibuja lo que manda el worker
 * ============================================================
 */

export interface FrameData {
  tr: Float32Array; // por agente: R cuerpos × (x,y,z, qx,qy,qz,qw)
  look: Uint8Array; // 0 normal, 1 top-3, 2 líder, 3 caído, 4 manual, 5 cerebro entrenado
  lane: Float32Array; // desplazamiento visual en z
  focus: number;
  assist: number;
  n: number;
}

export const CAMERA_MODES = [
  { name: "Atrás", yaw: Math.PI, pitch: 0.32, dist: 5.2 },
  { name: "Lateral", yaw: Math.PI / 2, pitch: 0.18, dist: 4.6 },
  { name: "Frente", yaw: 0.55, pitch: 0.3, dist: 5.0 },
  { name: "Aérea", yaw: Math.PI, pitch: 1.3, dist: 9 },
];

const LOOK_COLORS = [0x4f8fd6, 0x4ade80, 0xfbbf24, 0x6b7280, 0x22d3ee, 0xc084fc];
const R = RENDER_BODIES.length;

interface AgentView {
  group: THREE.Group;
  meshes: THREE.Mesh[];
  harness: THREE.Mesh;
  look: number;
}

export class Scene3D {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(55, 1, 0.1, 400);
  private agents: AgentView[] = [];
  private geoms: THREE.BufferGeometry[] = [];
  private mats: THREE.MeshLambertMaterial[][] = []; // [look][accent]
  private harnessMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.3, depthWrite: false });
  private harnessGeo = new THREE.CylinderGeometry(0.012, 0.012, 1, 4);
  private terrainMesh: THREE.Mesh | null = null;
  private terrainMat: THREE.MeshLambertMaterial;
  private labels: THREE.Sprite[] = [];
  private sun: THREE.DirectionalLight;
  private target = new THREE.Vector3(0, 1, 0);
  private view = { yaw: Math.PI, pitch: 0.32, dist: 5.2 };
  private goal = { yaw: Math.PI, pitch: 0.32, dist: 5.2 };
  private mode = 0;
  private quality = 0;
  private mobile: boolean;
  private shake = 0;

  constructor(private canvas: HTMLCanvasElement, mobile: boolean) {
    this.mobile = mobile;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: !mobile, powerPreference: "high-performance" });
    this.renderer.setClearColor(0x9fd0f5);
    this.scene.fog = new THREE.Fog(0xb9dcf7, 22, 95);

    this.scene.add(new THREE.HemisphereLight(0xdff1ff, 0x6a7a55, 1.05));
    this.sun = new THREE.DirectionalLight(0xffffff, 1.6);
    this.sun.position.set(6, 14, 8);
    this.sun.castShadow = false;
    this.sun.shadow.mapSize.set(1024, 1024);
    const sc = this.sun.shadow.camera;
    sc.left = -9; sc.right = 9; sc.top = 9; sc.bottom = -9; sc.near = 1; sc.far = 40;
    this.scene.add(this.sun, this.sun.target);

    // suelo lejano (vacío oscuro bajo la plataforma)
    const void_ = new THREE.Mesh(new THREE.PlaneGeometry(800, 800), new THREE.MeshLambertMaterial({ color: 0x5b7a52 }));
    void_.rotation.x = -Math.PI / 2;
    void_.position.set(100, -0.6, 0);
    void_.receiveShadow = false;
    this.scene.add(void_);

    // textura de ajedrez para el terreno
    const c = document.createElement("canvas");
    c.width = c.height = 64;
    const g = c.getContext("2d")!;
    g.fillStyle = "#8fbf6a"; g.fillRect(0, 0, 64, 64);
    g.fillStyle = "#7aac58"; g.fillRect(0, 0, 32, 32); g.fillRect(32, 32, 32, 32);
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.magFilter = THREE.NearestFilter;
    tex.anisotropy = 4;
    this.terrainMat = new THREE.MeshLambertMaterial({ map: tex });

    // materiales por aspecto
    LOOK_COLORS.forEach((col) => {
      const base = new THREE.MeshLambertMaterial({ color: col });
      const dark = new THREE.MeshLambertMaterial({ color: new THREE.Color(col).multiplyScalar(0.55) });
      this.mats.push([base, dark]);
    });

    // geometrías compartidas
    for (const i of RENDER_BODIES) {
      const b = BODY_SPECS[i];
      let geo: THREE.BufferGeometry;
      if (b.shape === "box") geo = new THREE.BoxGeometry(b.size[0] * 2, b.size[1] * 2, b.size[2] * 2);
      else if (b.shape === "capsule") geo = new THREE.CapsuleGeometry(b.size[1], b.size[0] * 2, 3, 8);
      else geo = new THREE.SphereGeometry(b.size[0], 12, 8);
      this.geoms.push(geo);
    }
    // marcas de distancia
    for (let d = 10; d <= 130; d += 10) {
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.labelTexture(`${d} m`), depthWrite: false, fog: false }));
      sp.scale.set(2.4, 1.2, 1);
      sp.userData.x = d;
      this.labels.push(sp);
      this.scene.add(sp);
    }
    this.setQuality(0);
    this.setCameraMode(0);
  }

  private labelTexture(text: string) {
    const c = document.createElement("canvas");
    c.width = 256; c.height = 128;
    const g = c.getContext("2d")!;
    g.fillStyle = "rgba(15,23,42,0.55)";
    g.beginPath(); g.roundRect(8, 24, 240, 80, 24); g.fill();
    g.fillStyle = "#fff"; g.font = "bold 56px sans-serif"; g.textAlign = "center"; g.textBaseline = "middle";
    g.fillText(text, 128, 66);
    return new THREE.CanvasTexture(c);
  }

  // ------------------------------------------------------------ calidad
  setQuality(level: number) {
    this.quality = level;
    const dpr = window.devicePixelRatio || 1;
    const caps = this.mobile ? [1.5, 1.25, 1, 0.75] : [2, 1.5, 1.25, 1];
    this.renderer.setPixelRatio(Math.min(dpr, caps[Math.min(level, 3)]));
    const shadows = !this.mobile && level === 0;
    this.renderer.shadowMap.enabled = shadows;
    this.sun.castShadow = shadows;
    this.resize();
    for (const a of this.agents) for (const m of a.meshes) m.castShadow = shadows;
    this.terrainMesh && (this.terrainMesh.receiveShadow = shadows);
    this.scene.traverse((o) => {
      const m = (o as THREE.Mesh).material as THREE.Material | undefined;
      if (m) m.needsUpdate = true;
    });
  }

  resize() {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.fov = w / h < 0.8 ? 68 : 55; // más campo de visión en vertical (celular)
    this.camera.updateProjectionMatrix();
  }

  // ------------------------------------------------------------ terreno
  setProfile(pieces: Piece[]) {
    if (this.terrainMesh) {
      this.scene.remove(this.terrainMesh);
      this.terrainMesh.geometry.dispose();
    }
    const hw = CONFIG.terrainHalfWidth;
    const pos: number[] = [];
    const uv: number[] = [];
    const quad = (a: number[], b: number[], c: number[], d: number[]) => {
      // a,b,c,d en sentido antihorario visto desde el lado visible
      for (const v of [a, b, c, a, c, d]) {
        pos.push(v[0], v[1], v[2]);
      }
    };
    const uvQuad = (u: number[][]) => {
      for (const k of [0, 1, 2, 0, 2, 3]) uv.push(u[k][0], u[k][1]);
    };
    for (let i = 0; i < pieces.length; i++) {
      const p = pieces[i];
      // cara superior
      quad([p.x0, p.y0, hw], [p.x1, p.y1, hw], [p.x1, p.y1, -hw], [p.x0, p.y0, -hw]);
      uvQuad([[p.x0 / 2, hw / 2], [p.x1 / 2, hw / 2], [p.x1 / 2, -hw / 2], [p.x0 / 2, -hw / 2]]);
      // contrahuella (salto vertical) entre piezas
      const nx = pieces[i + 1];
      if (nx && Math.abs(nx.y0 - p.y1) > 1e-6) {
        const lo = Math.min(p.y1, nx.y0);
        const hi = Math.max(p.y1, nx.y0);
        const x = p.x1;
        if (nx.y0 > p.y1) quad([x, lo, hw], [x, hi, hw], [x, hi, -hw], [x, lo, -hw]); // cara que mira a -X
        else quad([x, hi, -hw], [x, hi, hw], [x, lo, hw], [x, lo, -hw]); // cara que mira a +X
        uvQuad([[0, lo], [0, hi], [hw, hi], [hw, lo]].map(([a, b]) => [a / 2 + x / 2, b * 2]));
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
    geo.computeVertexNormals();
    // la normal debe apuntar hacia arriba en las caras superiores
    this.terrainMesh = new THREE.Mesh(geo, this.terrainMat);
    this.terrainMesh.receiveShadow = this.renderer.shadowMap.enabled;
    this.terrainMat.side = THREE.DoubleSide;
    this.scene.add(this.terrainMesh);
    for (const sp of this.labels) sp.position.set(sp.userData.x, terrainY(pieces, sp.userData.x) + 3.2, 0);
  }

  // ------------------------------------------------------------ agentes
  private ensureAgents(n: number) {
    while (this.agents.length < n) {
      const group = new THREE.Group();
      const meshes: THREE.Mesh[] = [];
      RENDER_BODIES.forEach((bi, k) => {
        const spec = BODY_SPECS[bi];
        const m = new THREE.Mesh(this.geoms[k], this.mats[0][spec.part === "foot" || spec.name === "pelvis" ? 1 : 0]);
        m.castShadow = this.renderer.shadowMap.enabled;
        if (spec.part === "head") {
          const visor = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.05, 0.14), new THREE.MeshLambertMaterial({ color: 0x0f172a }));
          visor.position.set(0.075, 0.015, 0);
          m.add(visor);
        }
        group.add(m);
        meshes.push(m);
      });
      const harness = new THREE.Mesh(this.harnessGeo, this.harnessMat);
      harness.visible = false;
      group.add(harness);
      this.scene.add(group);
      this.agents.push({ group, meshes, harness, look: 0 });
    }
    while (this.agents.length > n) {
      const a = this.agents.pop()!;
      this.scene.remove(a.group);
    }
  }

  setCameraMode(i: number) {
    this.mode = i % CAMERA_MODES.length;
    const m = CAMERA_MODES[this.mode];
    this.goal = { yaw: m.yaw, pitch: m.pitch, dist: m.dist };
    return this.mode;
  }
  get qualityLevel() {
    return this.quality;
  }
  get cameraMode() {
    return this.mode;
  }
  /** Sacudida de cámara breve (al empujar). */
  kick() {
    this.shake = 0.25;
  }

  // ------------------------------------------------------------ entrada táctil
  orbit(dx: number, dy: number) {
    this.goal.yaw -= dx * 0.008;
    this.goal.pitch = Math.max(0.03, Math.min(1.45, this.goal.pitch + dy * 0.006));
  }
  zoom(factor: number) {
    this.goal.dist = Math.max(2.2, Math.min(26, this.goal.dist * factor));
  }

  // ------------------------------------------------------------ dibujado
  render(f: FrameData | null, dt: number) {
    if (f) {
      this.ensureAgents(f.n);
      for (let i = 0; i < f.n; i++) {
        const a = this.agents[i];
        a.group.position.z = f.lane[i];
        const l = f.look[i];
        const base = i * R * 7;
        if (a.look !== l) {
          a.look = l;
          RENDER_BODIES.forEach((bi, k) => {
            const spec = BODY_SPECS[bi];
            a.meshes[k].material = this.mats[l][spec.part === "foot" || spec.name === "pelvis" ? 1 : 0];
          });
        }
        for (let k = 0; k < R; k++) {
          const o = base + k * 7;
          const m = a.meshes[k];
          m.position.set(f.tr[o], f.tr[o + 1], f.tr[o + 2]);
          m.quaternion.set(f.tr[o + 3], f.tr[o + 4], f.tr[o + 5], f.tr[o + 6]);
        }
        const showH = f.assist > 0.02 && l !== 3;
        a.harness.visible = showH;
        if (showH) {
          const H = 4;
          a.harness.scale.set(1, H, 1);
          a.harness.position.set(f.tr[base], f.tr[base + 1] + H / 2, 0);
        }
      }
      this.harnessMat.opacity = 0.12 + 0.4 * f.assist;
      // objetivo de la cámara: pelvis del personaje en foco
      const fi = Math.min(f.focus, f.n - 1);
      const o = fi * R * 7;
      const tx = f.tr[o], ty = f.tr[o + 1] * 0.8 + 0.2, tz = f.tr[o + 2] + f.lane[fi];
      const k = 1 - Math.exp(-dt * 4);
      this.target.x += (tx - this.target.x) * k;
      this.target.y += (ty - this.target.y) * k;
      this.target.z += (tz - this.target.z) * k;
    }
    // suavizado de la cámara
    const k2 = 1 - Math.exp(-dt * 6);
    let dyaw = this.goal.yaw - this.view.yaw;
    dyaw = Math.atan2(Math.sin(dyaw), Math.cos(dyaw));
    this.view.yaw += dyaw * k2;
    this.view.pitch += (this.goal.pitch - this.view.pitch) * k2;
    this.view.dist += (this.goal.dist - this.view.dist) * k2;
    const { yaw, pitch, dist } = this.view;
    const cp = Math.cos(pitch);
    this.camera.position.set(
      this.target.x + dist * cp * Math.cos(yaw),
      this.target.y + dist * Math.sin(pitch) + 0.3,
      this.target.z + dist * cp * Math.sin(yaw),
    );
    if (this.shake > 0) {
      this.shake -= dt;
      const s = this.shake * 0.4;
      this.camera.position.x += (Math.random() - 0.5) * s;
      this.camera.position.y += (Math.random() - 0.5) * s;
    }
    this.camera.lookAt(this.target);
    this.sun.position.set(this.target.x + 6, 14, this.target.z + 8);
    this.sun.target.position.copy(this.target);
    this.renderer.render(this.scene, this.camera);
  }

  dispose() {
    this.renderer.dispose();
  }
}
