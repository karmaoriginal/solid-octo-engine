/**
 * ============================================================
 *  PARÁMETROS AJUSTABLES  (todo lo "tuneable" está aquí arriba)
 * ============================================================
 * Unidades: metros, kilogramos, segundos, radianes.
 */
export const CONFIG = {
  // ---------- Física ----------
  physicsDt: 1 / 60, // paso de física
  controlEvery: 2, // la IA decide cada N pasos de física (30 Hz)
  gravity: -9.81,
  groundFriction: 1.0,
  solverIterations: 4,

  // ---------- Motores (músculos) ----------
  /** Error (rad) con el que el motor llega a su torque máximo. Menor = más rígido. */
  motorFullTorqueError: 0.03,
  /** Amortiguamiento del motor como fracción del torque máximo (N·m por rad/s). */
  motorDampingFactor: 0.2,
  /** Amortiguamiento cuando el personaje está "muerto" (músculos relajados). */
  limpDamping: 1.5,
  /** Multiplicador global de torque de todos los músculos. */
  torqueScale: 1.0,

  // ---------- Episodios ----------
  episodeSeconds: 10, // duración máxima de un intento
  lingerSeconds: 0.8, // tiempo que se ve caer el cuerpo antes de reiniciar
  terrainLength: 140,
  terrainHalfWidth: 22,
  laneWidth: 1.4, // separación entre agentes (carriles)

  // ---------- Evolución ----------
  /** Candidatos nuevos por generación (par, se usan en espejo) + 1 élite. */
  sampledPerGeneration: 24,
  initialSigma: 0.35,
  sigmaMin: 0.1,
  /** Escala de mutación relativa para los parámetros del oscilador (CPG) y de la red. */
  cpgScale: 0.5,
  nnScale: 0.12,
  nnHidden: 10,
  /** La red neuronal empieza a mutar cuando la ayuda baja de este valor (y a pleno a -0.25). */
  nnStartAssist: 0.85,
  targetSpeed: 1.6, // m/s de velocidad que se premia como máximo

  // ---------- Recompensa (valores por segundo salvo indicación) ----------
  reward: {
    alive: 0.6, // estar erguido y alto
    forward: 8.0, // avanzar hacia +X (solo cuenta si va erguido)
    energy: 0.6, // castigo por esfuerzo muscular
    jerk: 1.2, // castigo por movimientos espasmódicos
    straight: 0.8, // castigo por desviarse de la dirección objetivo
    drag: 2.0, // castigo por arrastrar rodillas/piernas por el suelo
    stepBonus: 0.7, // por paso alternado hacia delante (por evento)
    sameFootPenalty: 0.2, // por apoyar dos veces seguidas el mismo pie (por evento)
    fall: 2.5, // castigo fijo por caerse
  },
  // Condiciones de caída
  fall: {
    pelvisMinHeight: 0.5,
    headMinHeight: 0.7,
    minUpright: 0.35,
  },

  // ---------- Arnés de equilibrio (currículo) ----------
  /** Al empezar un arnés virtual endereza el torso y soporta parte del peso. Se retira solo al mejorar. */
  assist: {
    start: 1.0,
    tiltKp: 120, // aceleración angular (rad/s² por rad) para enderezar el tronco (a ayuda=1)
    tiltKd: 16,
    yawKp: 40,
    yawKd: 8,
    weightSupport: 0.5, // fracción del peso que sostiene a ayuda=1
    /** La ayuda baja `step` cuando la élite completa el episodio recorriendo al menos `minDist` m. */
    step: 0.08,
    minDist: 1.5,
    /** Si pasan tantas generaciones sin bajar, baja `slowStep` igualmente. */
    stallGenerations: 40,
    slowStep: 0.04,
    /** Los terrenos nuevos solo se desbloquean cuando la ayuda ya es menor o igual a este valor. */
    unlockMax: 0.25,
  },

  // ---------- Currículo de terrenos ----------
  /** Mejor distancia (m) necesaria para desbloquear: plano, pendientes, escalones, obstáculos. */
  unlockDistances: [0, 6, 9, 12],

  // ---------- Rendimiento ----------
  agentsDesktop: 24,
  agentsMobile: 12,
  minAgents: 4,
  /** Milisegundos máximos de física por fotograma (se reduce solo si baja el FPS). */
  simBudgetMs: 9,
  pushImpulse: 140, // N·s al pulsar "Empujar"
};

export type Config = typeof CONFIG;

export const TERRAINS = [
  { id: "flat", name: "Plano", icon: "▭" },
  { id: "slopes", name: "Pendientes", icon: "◢" },
  { id: "stairs", name: "Escalones", icon: "▟" },
  { id: "obstacles", name: "Obstáculos", icon: "▮" },
] as const;

export type TerrainId = (typeof TERRAINS)[number]["id"];
