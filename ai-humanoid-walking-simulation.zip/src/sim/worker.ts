/// <reference lib="webworker" />
import { Simulation, type Mode } from "./sim";
import { RENDER_BODIES } from "./spec";

/**
 * ============================================================
 *  WORKER: corre la física y el entrenamiento fuera del hilo de la interfaz
 * ============================================================
 * La interfaz nunca se bloquea: el worker avanza la simulación tanto como permita el tiempo
 * (según la velocidad pedida x1/x5/x20/x100) y manda ~60 veces por segundo las poses de los
 * cuerpos, más un resumen de estadísticas 4 veces por segundo.
 */

const ctx = self as unknown as DedicatedWorkerGlobalScope;

let sim: Simulation | null = null;
let speed = 1;
let paused = false;
let budgetMs = 12;
let last = performance.now();
let acc = 0;
let lastPost = 0;
let lastSnap = 0;
let sentHistory = -1;
let sentTerrain = -1;
let winSteps = 0;
let winStart = performance.now();
let effSpeed = 0;
let stepMs = 0; // coste medio de un paso (todas las instancias)

const channel = new MessageChannel();
channel.port1.onmessage = () => loop();

function schedule() {
  if (speed > 1 && !paused) channel.port2.postMessage(0);
  else setTimeout(loop, 3);
}

function loop() {
  const now = performance.now();
  const dtReal = Math.min(now - last, 100);
  last = now;
  if (sim) {
    if (!paused) {
      acc += (dtReal / 1000) * 60 * speed;
      if (speed <= 1 && acc > 6) acc = 6;
      const t0 = performance.now();
      let n = 0;
      while (acc >= 1 && performance.now() - t0 < budgetMs) {
        sim.stepOnce();
        acc -= 1;
        n++;
      }
      if (acc >= 1 && speed > 1) acc = 0; // no da abasto: se descarta el atraso
      if (n > 0) {
        const el = performance.now() - t0;
        stepMs = stepMs * 0.9 + (el / n) * 0.1;
      }
      winSteps += n;
    }
    const t = performance.now();
    if (t - winStart >= 1000) {
      effSpeed = paused ? 0 : winSteps / ((t - winStart) / 1000) / 60;
      winSteps = 0;
      winStart = t;
    }
    if (t - lastPost >= 15) {
      lastPost = t;
      postFrame();
    }
    if (t - lastSnap >= 250) {
      lastSnap = t;
      postSnapshot();
    }
  }
  schedule();
}

function postFrame() {
  if (!sim) return;
  const s = sim;
  s.updateFocus();
  const R = RENDER_BODIES.length;
  const n = s.slots.length;
  const tr = new Float32Array(n * R * 7);
  const look = new Uint8Array(n);
  const lane = new Float32Array(n);
  const cur = new Float32Array(n * 2); // distancia actual y recompensa actual
  // ranking de los que siguen de pie por recompensa acumulada
  const alive: number[] = [];
  for (let i = 0; i < n; i++) if (s.slots[i].role === "es" && s.slots[i].state === "run") alive.push(i);
  alive.sort((a, b) => s.slots[b].fit - s.slots[a].fit);
  const top = new Set(alive.slice(0, 3));
  let o = 0;
  for (let i = 0; i < n; i++) {
    const slot = s.slots[i];
    const bodies = slot.agent.bodies;
    for (let k = 0; k < R; k++) {
      const b = bodies[RENDER_BODIES[k]];
      const p = b.translation();
      const q = b.rotation();
      tr[o++] = p.x; tr[o++] = p.y; tr[o++] = p.z;
      tr[o++] = q.x; tr[o++] = q.y; tr[o++] = q.z; tr[o++] = q.w;
    }
    lane[i] = slot.laneZ;
    cur[i * 2] = slot.maxDist;
    cur[i * 2 + 1] = slot.fit;
    let l = 0;
    if (slot.state !== "run") l = 3;
    else if (slot.role === "manual") l = 4;
    else if (slot.role === "brain") l = 5;
    else if (top.has(i)) l = 1;
    if (i === s.focus && slot.state === "run" && slot.role === "es") l = 2;
    look[i] = l;
  }
  const msg: Record<string, unknown> = { t: "frame", tr, look, lane, cur, focus: s.focus, assist: s.assist, n };
  ctx.postMessage(msg, [tr.buffer]);
  if (sentTerrain !== s.terrainVersion) {
    sentTerrain = s.terrainVersion;
    ctx.postMessage({ t: "profile", pieces: s.profile, terrainIdx: s.terrainIdx });
  }
}

function postSnapshot() {
  if (!sim) return;
  const snap = sim.snapshot() as Record<string, unknown>;
  const hist = snap.history as unknown[];
  if (hist.length !== sentHistory) sentHistory = hist.length;
  else delete snap.history;
  snap.effSpeed = effSpeed;
  snap.stepMs = stepMs;
  snap.speed = speed;
  snap.autoAssist = sim.autoAssist;
  snap.autoCurriculum = sim.autoCurriculum;
  snap.unlockAll = sim.unlockAll;
  snap.slotCount = sim.slots.length;
  const events = sim.events.splice(0);
  ctx.postMessage({ t: "snap", snap, events });
}

ctx.onmessage = async (e: MessageEvent) => {
  const m = e.data;
  if (m.t === "init") {
    sim = await Simulation.create();
    sim.desiredSlots = m.agents;
    sim.configure("train");
    ctx.postMessage({ t: "ready" });
    last = performance.now();
    schedule();
    return;
  }
  if (!sim) return;
  switch (m.t) {
    case "speed": speed = m.v; break;
    case "pause": paused = !!m.v; break;
    case "budget": budgetMs = m.v; break;
    case "mode": sim.configure(m.mode as Mode); sentHistory = -1; break;
    case "terrain": sim.setTerrain(m.i); break;
    case "agents": sim.setSlotCount(m.n); break;
    case "push": sim.push(sim.mode === "train" ? sim.focus : m.slot ?? 0); break;
    case "manual": sim.manualU.set(m.u); break;
    case "resetSlot": sim.resetSlot(m.i); break;
    case "resetBrain": sim.resetBrain(); sentHistory = -1; break;
    case "unlockAll": sim.unlockAll = !!m.v; break;
    case "autoCurriculum": sim.autoCurriculum = !!m.v; break;
    case "assist":
      sim.autoAssist = !!m.auto;
      if (!m.auto) sim.assist = m.value;
      break;
    case "export": ctx.postMessage({ t: "brain", data: sim.exportBrain(), purpose: m.purpose }); break;
    case "import":
      try {
        sim.importBrain(m.data);
        sentHistory = -1;
        ctx.postMessage({ t: "toast", text: "✅ Cerebro cargado" });
      } catch (err) {
        ctx.postMessage({ t: "toast", text: "❌ " + (err as Error).message });
      }
      break;
  }
};
