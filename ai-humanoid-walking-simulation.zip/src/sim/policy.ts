import { CONFIG } from "../config";
import { N_JOINTS, N_OBS } from "./character";
import { JOINT_SPECS } from "./spec";
import { gaussian, type Rng } from "./rng";

/**
 * ============================================================
 *  CEREBRO (política de control)
 * ============================================================
 * Un "cerebro" es un vector de números (genoma) que define:
 *   1. Un oscilador central (CPG): cada articulación tiene amplitud, fase y sesgo propios y
 *      todas comparten una frecuencia. Da el ritmo base de la marcha.
 *   2. Una red neuronal (N_OBS → H → N_JOINTS, tanh) que recibe TODAS las observaciones
 *      (ángulos, velocidades, orientación, altura, contactos, velocidad, terreno) y corrige
 *      el ritmo para mantener el equilibrio.
 *   acción_j = tanh( sesgo_j + amp_j·sin(2π f t + fase_j) + red_j(obs) )   ∈ [-1, 1]
 * La evolución (es.ts) ajusta estos números; no hay nada programado sobre cómo caminar.
 */

const H = CONFIG.nnHidden;

/**
 * El oscilador es simétrico: las articulaciones se agrupan por tipo (cadera-flexión, rodilla, ...)
 * y el lado derecho usa los mismos parámetros que el izquierdo con media vuelta (π) de desfase,
 * lo que da pasos alternados "de fábrica". Las articulaciones centrales (columna, cuello) son únicas.
 */
const GROUPS: string[] = [];
const JOINT_GROUP: number[] = [];
const JOINT_RIGHT: boolean[] = [];
JOINT_SPECS.forEach((j) => {
  const right = / R( |$)/.test(j.name);
  const key = j.name.replace(/ [LR]( |$)/, "$1");
  let g = GROUPS.indexOf(key);
  if (g < 0) {
    g = GROUPS.length;
    GROUPS.push(key);
  }
  JOINT_GROUP.push(g);
  JOINT_RIGHT.push(right);
});
const NG = GROUPS.length;

const OFF_FREQ = 0;
const OFF_AMP = 1;
const OFF_PHASE = OFF_AMP + NG;
const OFF_BIAS = OFF_PHASE + NG;
const OFF_W1 = OFF_BIAS + NG;
const OFF_B1 = OFF_W1 + H * N_OBS;
const OFF_W2 = OFF_B1 + H;
const OFF_B2 = OFF_W2 + N_JOINTS * H;
export const GENOME_SIZE = OFF_B2 + N_JOINTS;
/** Número de parámetros del oscilador (van al principio del genoma). */
export const CPG_PARAMS = OFF_W1;

/** Frecuencia del oscilador en Hz a partir del parámetro del genoma. */
export function genomeFreq(g: ArrayLike<number>) {
  return Math.min(2.6, Math.max(0.7, 1.4 + 0.35 * g[OFF_FREQ]));
}

/** Cerebro inicial aleatorio: se retuerce sin sentido. */
export function initGenome(rng: Rng): Float32Array {
  const g = new Float32Array(GENOME_SIZE);
  g[OFF_FREQ] = gaussian(rng) * 0.5;
  for (let k = 0; k < NG; k++) {
    g[OFF_AMP + k] = gaussian(rng) * 0.3;
    g[OFF_PHASE + k] = rng() * Math.PI * 2;
  }
  const s1 = 1 / Math.sqrt(N_OBS);
  for (let i = 0; i < H * N_OBS; i++) g[OFF_W1 + i] = gaussian(rng) * s1;
  for (let i = 0; i < N_JOINTS * H; i++) g[OFF_W2 + i] = gaussian(rng) * 0.05;
  return g;
}

/** Escala relativa de mutación de cada parámetro. */
export function mutationScales(): Float32Array {
  const s = new Float32Array(GENOME_SIZE);
  for (let i = 0; i < OFF_W1; i++) s[i] = CONFIG.cpgScale;
  for (let i = OFF_W1; i < GENOME_SIZE; i++) s[i] = CONFIG.nnScale;
  s[OFF_FREQ] = CONFIG.cpgScale * 0.4;
  for (let k = 0; k < NG; k++) s[OFF_PHASE + k] = CONFIG.cpgScale * 1.2;
  return s;
}

export class Policy {
  g: ArrayLike<number> = new Float32Array(GENOME_SIZE);
  freq = 1.4;
  private hid = new Float32Array(H);

  set(genome: ArrayLike<number>) {
    this.g = genome;
    this.freq = genomeFreq(genome);
  }

  /** Calcula las acciones u (N_JOINTS valores en [-1,1]) a partir de las observaciones. */
  act(obs: Float32Array, t: number, u: Float32Array) {
    const g = this.g;
    const hid = this.hid;
    for (let h = 0; h < H; h++) {
      let s = g[OFF_B1 + h];
      const base = OFF_W1 + h * N_OBS;
      for (let i = 0; i < N_OBS; i++) s += g[base + i] * obs[i];
      hid[h] = Math.tanh(s);
    }
    const ph = 2 * Math.PI * this.freq * t;
    for (let j = 0; j < N_JOINTS; j++) {
      let o = g[OFF_B2 + j];
      const base = OFF_W2 + j * H;
      for (let h = 0; h < H; h++) o += g[base + h] * hid[h];
      const k = JOINT_GROUP[j];
      const shift = JOINT_RIGHT[j] ? Math.PI : 0;
      u[j] = Math.tanh(g[OFF_BIAS + k] + g[OFF_AMP + k] * Math.sin(ph + g[OFF_PHASE + k] + shift) + o);
    }
  }
}
