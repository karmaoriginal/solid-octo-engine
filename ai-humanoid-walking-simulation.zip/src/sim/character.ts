import RAPIER from "@dimforge/rapier3d-compat";
import { CONFIG } from "../config";
import { terrainY, type Piece } from "./terrain";

/**
 * ============================================================
 *  PERSONAJE HUMANOIDE (ragdoll con músculos)
 * ============================================================
 * - 13 segmentos con masa real + 7 cuerpos "bisagra" ligeros que permiten articulaciones de 2 ejes.
 * - 19 grados de libertad (cada uno una bisagra con límites y motor de torque limitado).
 * - Pose de reposo: de pie, todos los cuerpos con rotación identidad. +X = adelante, +Y = arriba.
 *   Así, el ángulo de cada articulación se obtiene directamente de la rotación relativa.
 */

import {
  BODY_INDEX,
  BODY_SPECS,
  JOINT_SPECS,
  N_BODIES,
  N_JOINTS,
  STAND_PELVIS_Y,
  TOTAL_MASS,
} from "./spec";

export { BODY_INDEX, BODY_SPECS, JOINT_SPECS, N_BODIES, N_JOINTS, STAND_PELVIS_Y, TOTAL_MASS };
const bodies = BODY_SPECS;
const joints = JOINT_SPECS;
const idx = BODY_INDEX;
const UPRIGHT_BODIES = [idx.pelvis, idx.chest];
const jParent = joints.map((j) => idx[j.parent]);
const jChild = joints.map((j) => idx[j.child]);

/** Número de valores del vector de observación. */
export const N_OBS = N_JOINTS * 2 + 3 + 3 + 3 + 1 + 3 + 3 + 2 + 2 + 2;

const GROUP_AGENT = 0x00020001; // pertenece al grupo 2, solo choca con el grupo 1 (terreno)
export const GROUP_TERRAIN = 0x0001ffff;

const jointRange = joints.map((j) => j.max - j.min);
const jointMid = joints.map((j) => (j.max + j.min) / 2);

function clamp(v: number, a: number, b: number) {
  return v < a ? a : v > b ? b : v;
}

/** Un personaje completo dentro del mundo de física. */
export class Agent {
  bodies: RAPIER.RigidBody[] = [];
  joints: RAPIER.RevoluteImpulseJoint[] = [];
  private q = new Float64Array(N_BODIES * 4);
  angle = new Float32Array(N_JOINTS);
  vel = new Float32Array(N_JOINTS);
  private prevAngle = new Float32Array(N_JOINTS);
  private needInit = true;
  /** Fracción de torque estimada que usó cada motor en la última decisión. */
  torqueFrac = new Float32Array(N_JOINTS);
  limp = false;
  enabled = true;

  // estado del tronco
  px = 0; py = 0; pz = 0; // pelvis
  vx = 0; vy = 0; vz = 0;
  wx = 0; wy = 0; wz = 0;
  upX = 0; upZ = 0;
  upY = 1; // componente vertical del eje "arriba" de la pelvis
  chestUpY = 1;
  fwdZ = 0; // componente lateral del eje "adelante" de la pelvis
  headY = 0;
  chestY = 0;
  footX = [0, 0];
  footY = [0, 0];
  shinY = [0, 0];
  // filas de la matriz de rotación (mundo expresado en el cuerpo)
  private pUp = [0, 1, 0];
  private pFwd = [1, 0, 0];
  private cUp = [0, 1, 0];

  constructor(private world: RAPIER.World) {
    for (const b of bodies) {
      const desc = RAPIER.RigidBodyDesc.dynamic()
        .setTranslation(b.pos[0], b.pos[1], b.pos[2])
        .setLinearDamping(0.02)
        .setAngularDamping(0.05)
        .setCanSleep(false);
      if (b.shape === "dummy") {
        const I = 0.02;
        desc.setAdditionalMassProperties(b.mass, { x: 0, y: 0, z: 0 }, { x: I, y: I, z: I }, { x: 0, y: 0, z: 0, w: 1 });
      }
      const body = world.createRigidBody(desc);
      if (b.shape !== "dummy") {
        let cd: RAPIER.ColliderDesc;
        if (b.shape === "box") cd = RAPIER.ColliderDesc.cuboid(b.size[0], b.size[1], b.size[2]);
        else if (b.shape === "capsule") cd = RAPIER.ColliderDesc.capsule(b.size[0], b.size[1]);
        else cd = RAPIER.ColliderDesc.ball(b.size[0]);
        cd.setMass(b.mass).setFriction(b.friction).setRestitution(0).setCollisionGroups(GROUP_AGENT);
        world.createCollider(cd, body);
      }
      this.bodies.push(body);
    }
    joints.forEach((j, i) => {
      const bp = bodies[jParent[i]].pos;
      const bc = bodies[jChild[i]].pos;
      const a1 = { x: j.anchor[0] - bp[0], y: j.anchor[1] - bp[1], z: j.anchor[2] - bp[2] };
      const a2 = { x: j.anchor[0] - bc[0], y: j.anchor[1] - bc[1], z: j.anchor[2] - bc[2] };
      const data = RAPIER.JointData.revolute(a1, a2, { x: j.axis[0], y: j.axis[1], z: j.axis[2] });
      data.limitsEnabled = true;
      data.limits = [j.min, j.max];
      const joint = world.createImpulseJoint(data, this.bodies[jParent[i]], this.bodies[jChild[i]], true) as RAPIER.RevoluteImpulseJoint;
      joint.configureMotorModel(RAPIER.MotorModel.ForceBased);
      joint.setMotorMaxForce(j.maxTorque * CONFIG.torqueScale);
      this.joints.push(joint);
    });
  }

  /** Coloca al personaje de pie en (x, z) sobre el terreno y activa los músculos. */
  reset(x: number, z: number, groundY: number) {
    for (let i = 0; i < this.bodies.length; i++) {
      const b = this.bodies[i];
      const p = bodies[i].pos;
      b.setEnabled(true);
      b.setTranslation({ x: p[0] + x, y: p[1] + groundY + 0.01, z: p[2] + z }, false);
      b.setRotation({ x: 0, y: 0, z: 0, w: 1 }, false);
      b.setLinvel({ x: 0, y: 0, z: 0 }, false);
      b.setAngvel({ x: 0, y: 0, z: 0 }, false);
      b.resetForces(false);
      b.resetTorques(false);
      b.wakeUp();
    }
    this.limp = false;
    this.enabled = true;
    this.needInit = true;
    this.setRestTargets();
  }

  /** Congela el cuerpo (queda visible pero no cuesta cálculo). */
  freeze() {
    if (!this.enabled) return;
    for (const b of this.bodies) b.setEnabled(false);
    this.enabled = false;
  }

  remove() {
    for (const b of this.bodies) this.world.removeRigidBody(b);
    this.bodies.length = 0;
    this.joints.length = 0;
  }

  setRestTargets() {
    const kpBase = 1 / CONFIG.motorFullTorqueError;
    for (let i = 0; i < N_JOINTS; i++) {
      const j = joints[i];
      const mt = j.maxTorque * CONFIG.torqueScale;
      this.joints[i].configureMotorPosition(j.rest, mt * kpBase, mt * CONFIG.motorDampingFactor);
    }
  }

  /** Relaja todos los músculos (el personaje cae como un muñeco). */
  goLimp() {
    this.limp = true;
    for (let i = 0; i < N_JOINTS; i++) this.joints[i].configureMotorPosition(joints[i].rest, 0, CONFIG.limpDamping);
  }

  /** Convierte una acción normalizada u∈[-1,1] a ángulo objetivo (0 = pose de reposo). */
  static targetAngle(i: number, u: number) {
    const j = joints[i];
    return u >= 0 ? j.rest + u * (j.max - j.rest) : j.rest + u * (j.rest - j.min);
  }
  /** Inversa: ángulo → valor normalizado (para observaciones y esfuerzo). */
  static normAngle(i: number, a: number) {
    const j = joints[i];
    return a >= j.rest ? (a - j.rest) / (j.max - j.rest) : (a - j.rest) / (j.rest - j.min);
  }

  /** Aplica las acciones a los motores y estima el esfuerzo muscular. */
  applyActions(u: ArrayLike<number>) {
    if (this.limp) return;
    const kpBase = 1 / CONFIG.motorFullTorqueError;
    const dtc = CONFIG.physicsDt * CONFIG.controlEvery;
    void dtc;
    for (let i = 0; i < N_JOINTS; i++) {
      const j = joints[i];
      const t = Agent.targetAngle(i, clamp(u[i], -1, 1));
      const mt = j.maxTorque * CONFIG.torqueScale;
      this.joints[i].configureMotorPosition(t, mt * kpBase, mt * CONFIG.motorDampingFactor);
      // esfuerzo estimado = torque PD / torque máximo
      const tau = (t - this.angle[i]) * kpBase - this.vel[i] * CONFIG.motorDampingFactor;
      this.torqueFrac[i] = clamp(tau, -1, 1);
    }
  }

  /** Lee el estado de física: ángulos, velocidades, tronco, pies. */
  readState(dtc: number) {
    const q = this.q;
    for (let i = 0; i < N_BODIES; i++) {
      const r = this.bodies[i].rotation();
      q[i * 4] = r.x;
      q[i * 4 + 1] = r.y;
      q[i * 4 + 2] = r.z;
      q[i * 4 + 3] = r.w;
    }
    for (let j = 0; j < N_JOINTS; j++) {
      const a = jParent[j] * 4;
      const b = jChild[j] * 4;
      const ax = q[a], ay = q[a + 1], az = q[a + 2], aw = q[a + 3];
      const bx = q[b], by = q[b + 1], bz = q[b + 2], bw = q[b + 3];
      // q_rel = conj(a) * b
      const w = aw * bw + ax * bx + ay * by + az * bz;
      const vx = aw * bx - bw * ax - (ay * bz - az * by);
      const vy = aw * by - bw * ay - (az * bx - ax * bz);
      const vz = aw * bz - bw * az - (ax * by - ay * bx);
      const ax_ = joints[j].axis;
      let ang = 2 * Math.atan2(vx * ax_[0] + vy * ax_[1] + vz * ax_[2], w);
      if (ang > Math.PI) ang -= 2 * Math.PI;
      else if (ang < -Math.PI) ang += 2 * Math.PI;
      this.angle[j] = ang;
    }
    if (this.needInit) {
      this.prevAngle.set(this.angle);
      this.needInit = false;
    }
    for (let j = 0; j < N_JOINTS; j++) {
      this.vel[j] = (this.angle[j] - this.prevAngle[j]) / dtc;
      this.prevAngle[j] = this.angle[j];
    }
    const B = this.bodies;
    const pelvis = B[BODY_INDEX.pelvis];
    const t = pelvis.translation();
    const lv = pelvis.linvel();
    const av = pelvis.angvel();
    this.px = t.x; this.py = t.y; this.pz = t.z;
    this.vx = lv.x; this.vy = lv.y; this.vz = lv.z;
    this.wx = av.x; this.wy = av.y; this.wz = av.z;
    // pelvis
    {
      const x = q[BODY_INDEX.pelvis * 4], y = q[BODY_INDEX.pelvis * 4 + 1], z = q[BODY_INDEX.pelvis * 4 + 2], w = q[BODY_INDEX.pelvis * 4 + 3];
      this.pUp[0] = 2 * (x * y + w * z);
      this.pUp[1] = 1 - 2 * (x * x + z * z);
      this.pUp[2] = 2 * (y * z - w * x);
      this.pFwd[0] = 1 - 2 * (y * y + z * z);
      this.pFwd[1] = 2 * (x * y - w * z);
      this.pFwd[2] = 2 * (x * z + w * y);
      this.upX = 2 * (x * y - w * z);
      this.upY = this.pUp[1];
      this.upZ = 2 * (y * z + w * x);
      // eje "adelante" del cuerpo en el mundo (columna x de R) → componente z
      this.fwdZ = 2 * (x * z - w * y);
    }
    {
      const c = BODY_INDEX.chest * 4;
      const x = q[c], y = q[c + 1], z = q[c + 2], w = q[c + 3];
      this.cUp[0] = 2 * (x * y + w * z);
      this.cUp[1] = 1 - 2 * (x * x + z * z);
      this.cUp[2] = 2 * (y * z - w * x);
      this.chestUpY = this.cUp[1];
    }
    this.chestY = B[BODY_INDEX.chest].translation().y;
    this.headY = B[BODY_INDEX.head].translation().y;
    const fl = B[BODY_INDEX.footL].translation();
    const fr = B[BODY_INDEX.footR].translation();
    this.footX[0] = fl.x; this.footY[0] = fl.y;
    this.footX[1] = fr.x; this.footY[1] = fr.y;
    this.shinY[0] = B[BODY_INDEX.shinL].translation().y;
    this.shinY[1] = B[BODY_INDEX.shinR].translation().y;
  }

  /**
   * Arnés de equilibrio (currículo), parte 1 — fuerza vertical que sostiene parte del peso.
   * Se llama en cada decisión. `a` ∈ [0,1]; con a=0 no hay ninguna ayuda.
   */
  applyAssistForce(a: number, groundY: number) {
    const pelvis = this.bodies[BODY_INDEX.pelvis];
    pelvis.resetForces(false);
    if (a <= 0) return;
    const h = this.py - groundY;
    if (h < STAND_PELVIS_Y + 0.02) pelvis.addForce({ x: 0, y: a * CONFIG.assist.weightSupport * TOTAL_MASS * 9.81, z: 0 }, false);
  }

  /**
   * Arnés de equilibrio, parte 2 — acelera la rotación de pelvis y pecho hacia "erguido y mirando
   * a +X". Es un control por aceleración angular (estable); se llama en cada paso de física.
   */
  driveUpright(a: number, dt: number) {
    const A = CONFIG.assist;
    for (const bi of UPRIGHT_BODIES) {
      const b = this.bodies[bi];
      const r = b.rotation();
      const x = r.x, y = r.y, z = r.z, w = r.w;
      const upX = 2 * (x * y - w * z);
      const upZ = 2 * (y * z + w * x);
      const fz = 2 * (x * z - w * y);
      const v = b.angvel();
      const ax = a * (-A.tiltKp * upZ - A.tiltKd * v.x);
      const az = a * (A.tiltKp * upX - A.tiltKd * v.z);
      const ay = a * (A.yawKp * fz - A.yawKd * v.y);
      b.setAngvel({ x: v.x + clamp(ax, -300, 300) * dt, y: v.y + clamp(ay, -300, 300) * dt, z: v.z + clamp(az, -300, 300) * dt }, false);
    }
  }

  /** ¿El pie i está tocando el suelo? */
  footContact(i: number, prof: Piece[]) {
    return this.footY[i] - terrainY(prof, this.footX[i]) < 0.065;
  }

  /** Construye el vector de observación (N_OBS valores aprox. en [-1, 1]). */
  observe(out: Float32Array, t: number, freq: number, prof: Piece[]) {
    let k = 0;
    for (let i = 0; i < N_JOINTS; i++) out[k++] = clamp((this.angle[i] - jointMid[i]) / (jointRange[i] / 2), -1.5, 1.5);
    for (let i = 0; i < N_JOINTS; i++) out[k++] = clamp(this.vel[i] / 8, -1, 1);
    out[k++] = this.pUp[0]; out[k++] = this.pUp[1]; out[k++] = this.pUp[2];
    out[k++] = this.pFwd[0]; out[k++] = this.pFwd[1]; out[k++] = this.pFwd[2];
    out[k++] = this.cUp[0]; out[k++] = this.cUp[1]; out[k++] = this.cUp[2];
    const g = terrainY(prof, this.px);
    out[k++] = clamp((this.py - g) / STAND_PELVIS_Y, 0, 1.5) - 1;
    out[k++] = clamp(this.vx / 2, -1.5, 1.5); out[k++] = clamp(this.vy / 2, -1.5, 1.5); out[k++] = clamp(this.vz / 2, -1.5, 1.5);
    out[k++] = clamp(this.wx / 5, -1.5, 1.5); out[k++] = clamp(this.wy / 5, -1.5, 1.5); out[k++] = clamp(this.wz / 5, -1.5, 1.5);
    out[k++] = this.footContact(0, prof) ? 1 : -1;
    out[k++] = this.footContact(1, prof) ? 1 : -1;
    const ph = 2 * Math.PI * freq * t;
    out[k++] = Math.sin(ph);
    out[k++] = Math.cos(ph);
    // "vista" del terreno por delante (pendientes, escalones, obstáculos)
    out[k++] = clamp((terrainY(prof, this.px + 0.5) - g) / 0.2, -1, 1);
    out[k++] = clamp((terrainY(prof, this.px + 1.0) - g) / 0.3, -1, 1);
  }
}
