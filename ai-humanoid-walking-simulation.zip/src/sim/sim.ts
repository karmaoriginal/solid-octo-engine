import RAPIER from "@dimforge/rapier3d-compat";
import { CONFIG, TERRAINS, type TerrainId } from "../config";
import { Agent, GROUP_TERRAIN, N_JOINTS, N_OBS } from "./character";
import { Evolution } from "./es";
import { CPG_PARAMS, GENOME_SIZE, Policy, initGenome, mutationScales } from "./policy";
import { makeRng, type Rng } from "./rng";
import { buildProfile, pieceBox, terrainY, type Piece } from "./terrain";

/**
 * ============================================================
 *  SIMULACIÓN: mundo físico + agentes en paralelo + entrenamiento
 * ============================================================
 * Esta clase no sabe nada de gráficos (se puede ejecutar sin pantalla para pruebas).
 *
 * Cada "slot" es un personaje visible. En modo ENTRENAR los slots van tomando candidatos
 * (cerebros) de la generación actual; cuando uno se cae o se acaba el tiempo, su slot se reinicia
 * solo con el siguiente candidato. Cuando todos los candidatos fueron evaluados se aplica la
 * evolución y empieza la generación siguiente.
 */

export type Mode = "train" | "test" | "manual";
type Role = "es" | "brain" | "manual";
type SlotState = "run" | "linger" | "idle";

export interface GenStat {
  gen: number;
  terrain: number;
  bestDist: number;
  meanDist: number;
  bestFit: number;
  meanFit: number;
  meanTime: number;
}

export class Slot {
  /** Cada slot tiene su propio mundo físico, recreado en cada episodio (evaluación reproducible). */
  world!: RAPIER.World;
  agent!: Agent;
  role: Role = "es";
  policy = new Policy();
  state: SlotState = "idle";
  laneZ = 0;
  cand = -1;
  phys = 0;
  t = 0;
  fit = 0;
  x0 = 0;
  maxDist = 0;
  lingerT = 0;
  fell = false;
  contact = [true, true];
  lastStepFoot = -1;
  lastStepX = 0;
  obs = new Float32Array(N_OBS);
  u = new Float32Array(N_JOINTS);
  uPrev = new Float32Array(N_JOINTS);
  /** Crea un mundo nuevo con el terreno y un personaje nuevo. */
  build(profile: Piece[]) {
    if (this.world) this.world.free();
    const w = new RAPIER.World({ x: 0, y: CONFIG.gravity, z: 0 });
    w.timestep = CONFIG.physicsDt;
    w.integrationParameters.numSolverIterations = CONFIG.solverIterations;
    const ground = w.createRigidBody(RAPIER.RigidBodyDesc.fixed());
    const hw = CONFIG.terrainHalfWidth;
    for (const p of profile) {
      const b = pieceBox(p);
      const desc = RAPIER.ColliderDesc.cuboid(b.halfLen, b.halfThick, hw)
        .setTranslation(b.cx, b.cy, 0)
        .setRotation({ x: 0, y: 0, z: Math.sin(b.angle / 2), w: Math.cos(b.angle / 2) })
        .setFriction(CONFIG.groundFriction)
        .setRestitution(0)
        .setCollisionGroups(GROUP_TERRAIN);
      w.createCollider(desc, ground);
    }
    this.world = w;
    this.agent = new Agent(w);
  }
  dispose() {
    if (this.world) this.world.free();
  }
}

export interface BrainFile {
  format: "ia-camina";
  version: 1;
  genomeSize: number;
  mean: number[];
  elite: number[];
  sigma: number;
  gen: number;
  eliteFit: number;
  history: GenStat[];
  terrainBest: number[];
  unlocked: number;
  assist?: number;
  savedAt: string;
}

const round5 = (v: number) => Math.round(v * 1e5) / 1e5;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);

export class Simulation {
  slots: Slot[] = [];
  mode: Mode = "train";
  profile: Piece[] = [];
  terrainIdx = 0;
  terrainVersion = 0; // cambia cuando se reconstruye el terreno (el render lo detecta)
  unlocked = 0; // índice máximo de terreno desbloqueado
  autoCurriculum = true;
  terrainBest: number[] = TERRAINS.map(() => 0);
  unlockAll = false;
  /** Ayuda de equilibrio actual (1 = arnés completo, 0 = sin ayuda). */
  assist = CONFIG.assist.start;
  autoAssist = true;
  private assistStall = 0;

  evo!: Evolution;
  history: GenStat[] = [];
  private rng: Rng = makeRng(Date.now() & 0xffffff);
  private nextCand = 0;
  private results: ({ fit: number; dist: number; time: number } | null)[] = [];
  private completed = 0;
  /** Manual: valores normalizados [-1,1] de cada articulación. */
  manualU = new Float32Array(N_JOINTS);
  focus = 0;
  physSteps = 0;
  events: string[] = [];
  desiredSlots = CONFIG.agentsDesktop;

  static async create(): Promise<Simulation> {
    await RAPIER.init();
    const s = new Simulation();
    s.init();
    return s;
  }

  private init() {
    this.buildTerrain(0);
    this.evo = new Evolution(initGenome(this.rng), mutationScales(), this.rng);
    this.evo.denseCount = CPG_PARAMS;
    this.results = this.evo.cands.map(() => null);
  }

  // ------------------------------------------------------------------ terreno
  private buildTerrain(i: number) {
    this.terrainIdx = i;
    this.profile = buildProfile(TERRAINS[i].id as TerrainId);
    this.terrainVersion++;
  }

  isUnlocked(i: number) {
    return this.unlockAll || i <= this.unlocked;
  }

  setTerrain(i: number) {
    if (!this.isUnlocked(i) || i === this.terrainIdx) return;
    this.buildTerrain(i);
    this.restartAll(true);
  }

  // ------------------------------------------------------------------ slots y modos
  /** Prepara los slots según el modo actual. */
  configure(mode: Mode) {
    this.mode = mode;
    const roles: Role[] =
      mode === "train" ? Array.from({ length: this.desiredSlots }, () => "es" as Role) : mode === "test" ? ["brain"] : ["manual", "brain"];
    while (this.slots.length > roles.length) this.slots.pop()!.dispose();
    while (this.slots.length < roles.length) this.slots.push(new Slot());
    const n = roles.length;
    this.slots.forEach((s, i) => {
      s.role = roles[i];
      s.laneZ = (i - (n - 1) / 2) * CONFIG.laneWidth;
    });
    this.focus = 0;
    this.restartAll(true);
  }

  setSlotCount(n: number) {
    this.desiredSlots = n;
    if (this.mode === "train" && n !== this.slots.length) this.configure("train");
  }

  /** Reinicia todos los personajes (y la generación en curso si se pide). */
  restartAll(resetGeneration: boolean) {
    if (resetGeneration || this.mode !== "train") {
      this.nextCand = 0;
      this.completed = 0;
      this.results = this.evo.cands.map(() => null);
    }
    for (const s of this.slots) this.startEpisode(s);
  }

  /** Reinicia solo el personaje manual (o el cerebro) */
  resetSlot(i: number) {
    const s = this.slots[i];
    if (s) this.startEpisode(s);
  }

  private startEpisode(s: Slot) {
    if (s.role === "es") {
      if (this.nextCand >= this.evo.cands.length) {
        s.state = "idle";
        s.cand = -1;
        if (s.world) s.agent.freeze();
        return;
      }
      s.cand = this.nextCand++;
      s.policy.set(this.evo.cands[s.cand]);
    } else if (s.role === "brain") {
      s.policy.set(this.evo.elite);
    }
    s.build(this.profile);
    const a = s.agent;
    a.reset(0, 0, 0); // todos en z=0: la física es idéntica para cada candidato (el carril es solo visual)
    s.state = "run";
    s.phys = 0;
    s.t = 0;
    s.fit = 0;
    s.maxDist = 0;
    s.lingerT = 0;
    s.fell = false;
    s.contact[0] = s.contact[1] = true;
    s.lastStepFoot = -1;
    s.lastStepX = 0;
    s.x0 = 0;
    s.u.fill(0);
    s.uPrev.fill(0);
    // primera decisión
    this.decide(s);
  }

  /** Observa y decide acciones (sin recompensa). */
  private decide(s: Slot) {
    const a = s.agent;
    const dtc = CONFIG.physicsDt * CONFIG.controlEvery;
    a.readState(dtc);
    if (s.role === "manual") {
      s.u.set(this.manualU);
    } else {
      a.observe(s.obs, s.t, s.policy.freq, this.profile);
      s.policy.act(s.obs, s.t, s.u);
    }
    s.uPrev.set(s.u);
    a.applyActions(s.u);
  }

  // ------------------------------------------------------------------ paso de simulación
  /** Avanza un paso de física para todos los personajes. */
  stepOnce() {
    this.physSteps++;
    const dt = CONFIG.physicsDt;
    for (let i = 0; i < this.slots.length; i++) {
      const s = this.slots[i];
      if (s.state === "idle") continue;
      if (this.assist > 0 && s.state === "run") s.agent.driveUpright(this.assist, dt);
      s.world.step();
      s.phys++;
      if (s.state === "linger") {
        s.lingerT += dt;
        if (s.lingerT >= CONFIG.lingerSeconds) this.startEpisode(s);
        continue;
      }
      if (s.phys % CONFIG.controlEvery === 0) this.control(s);
    }
  }

  /** Un paso de control (30 Hz): leer, recompensar, decidir, actuar. */
  private control(s: Slot) {
    const a = s.agent;
    const R = CONFIG.reward;
    const F = CONFIG.fall;
    const dtc = CONFIG.physicsDt * CONFIG.controlEvery;
    s.t += dtc;

    if (s.role === "manual") {
      this.decide(s);
      a.applyAssistForce(this.assist, terrainY(this.profile, a.px));
      return;
    }
    a.readState(dtc);
    const prof = this.profile;
    const g = terrainY(prof, a.px);
    a.applyAssistForce(this.assist, g);
    const h = a.py - g;
    const dist = a.px - s.x0;
    if (dist > s.maxDist) s.maxDist = dist;
    const fell = h < F.pelvisMinHeight || a.headY - g < F.headMinHeight || a.upY < F.minUpright || a.chestUpY < F.minUpright;

    if (fell) {
      s.fell = true;
      a.goLimp();
      s.state = "linger";
      s.lingerT = 0;
      if (s.role === "es") {
        s.fit -= R.fall;
        this.finishEs(s); // puede terminar la generación y reiniciar todos los slots
      }
      return;
    }

    // ------- decidir
    a.observe(s.obs, s.t, s.policy.freq, prof);
    s.policy.act(s.obs, s.t, s.u);

    if (s.role === "es") {
      // ------- recompensa de este paso
      const hf = clamp((h - 0.45) / 0.5, 0, 1);
      const posture = hf * clamp(a.upY, 0, 1) * clamp(a.chestUpY, 0, 1);
      const vxc = clamp(a.vx, -1, CONFIG.targetSpeed);
      let energy = 0;
      let jerk = 0;
      for (let i = 0; i < N_JOINTS; i++) {
        energy += a.torqueFrac[i] * a.torqueFrac[i];
        const d = s.u[i] - s.uPrev[i];
        jerk += d * d;
      }
      energy /= N_JOINTS;
      jerk /= N_JOINTS;
      const drag = ((a.shinY[0] - g < 0.12 ? 1 : 0) + (a.shinY[1] - g < 0.12 ? 1 : 0)) * 0.5;
      const straight = Math.abs(a.fwdZ) + 0.3 * Math.abs(a.pz);
      let r =
        (R.alive * posture +
          R.forward * vxc * (0.2 + 0.8 * posture) -
          R.energy * energy -
          R.jerk * jerk -
          R.straight * straight -
          R.drag * drag) *
        dtc;
      // pasos alternados
      for (let f = 0; f < 2; f++) {
        const c = a.footContact(f, prof);
        if (c && !s.contact[f]) {
          if (s.lastStepFoot !== f) {
            if (a.px - s.lastStepX > 0.12) r += R.stepBonus;
            s.lastStepX = a.px;
          } else r -= R.sameFootPenalty;
          s.lastStepFoot = f;
        }
        s.contact[f] = c;
      }
      s.fit += r;
      if (s.t >= CONFIG.episodeSeconds) {
        if (!this.finishEs(s)) this.startEpisode(s);
        return;
      }
    } else if (s.role === "brain") {
      if (a.px > CONFIG.terrainLength - 5) {
        this.startEpisode(s);
        return;
      }
    }
    s.uPrev.set(s.u);
    a.applyActions(s.u);
  }

  // ------------------------------------------------------------------ evolución
  /** Registra el resultado de un candidato. Devuelve true si con esto terminó la generación. */
  private finishEs(s: Slot): boolean {
    if (s.cand < 0 || this.results[s.cand]) return false;
    this.results[s.cand] = { fit: s.fit, dist: s.maxDist, time: s.t };
    this.completed++;
    if (this.completed >= this.results.length) {
      this.endGeneration();
      return true;
    }
    return false;
  }

  private endGeneration() {
    const res = this.results as { fit: number; dist: number; time: number }[];
    const n = res.length;
    let bestDist = 0, sumDist = 0, bestFit = -Infinity, sumFit = 0, sumT = 0;
    for (const r of res) {
      bestDist = Math.max(bestDist, r.dist);
      sumDist += r.dist;
      bestFit = Math.max(bestFit, r.fit);
      sumFit += r.fit;
      sumT += r.time;
    }
    this.history.push({
      gen: this.evo.gen + 1,
      terrain: this.terrainIdx,
      bestDist,
      meanDist: sumDist / n,
      bestFit,
      meanFit: sumFit / n,
      meanTime: sumT / n,
    });
    if (this.history.length > 600) this.history.splice(0, this.history.length - 600);
    this.terrainBest[this.terrainIdx] = Math.max(this.terrainBest[this.terrainIdx], bestDist);
    this.updateAssist(res[0]);
    this.updateNnStage();
    this.evo.tell(res.map((r) => r.fit));
    this.checkUnlock();
    this.nextCand = 0;
    this.completed = 0;
    this.results = this.evo.cands.map(() => null);
    this.restartAll(false);
  }

  /** La red neuronal de reflejos empieza a aprender cuando el arnés ya se está retirando. */
  private updateNnStage() {
    this.evo.nnFactor = clamp((CONFIG.nnStartAssist - this.assist) / 0.25, 0, 1);
  }

  /** Retira el arnés poco a poco cuando la élite se desempeña bien con la ayuda actual. */
  private updateAssist(elite: { fit: number; dist: number; time: number }) {
    if (!this.autoAssist || this.assist <= 0) return;
    const A = CONFIG.assist;
    this.assistStall++;
    if (elite.time >= CONFIG.episodeSeconds - 0.1 && elite.dist >= A.minDist) {
      this.assist = Math.max(0, this.assist - A.step);
      this.assistStall = 0;
    } else if (this.assistStall >= A.stallGenerations) {
      this.assist = Math.max(0, this.assist - A.slowStep);
      this.assistStall = 0;
    }
    if (this.assist < 0.005) {
      this.assist = 0;
      this.events.push("🎓 ¡Arnés retirado! Ahora camina sin ayuda");
    }
  }

  /** Terreno i+1 se desbloquea al superar cierta distancia en el terreno i. */
  private checkUnlock() {
    const th = CONFIG.unlockDistances;
    while (this.unlocked < TERRAINS.length - 1 && this.assist <= CONFIG.assist.unlockMax && this.terrainBest[this.unlocked] >= th[this.unlocked + 1]) {
      this.unlocked++;
      this.events.push(`🔓 ¡Terreno desbloqueado: ${TERRAINS[this.unlocked].name}!`);
      if (this.autoCurriculum && this.unlocked === this.terrainIdx + 1) {
        this.buildTerrain(this.unlocked);
      }
    }
  }

  /** Reinicia el aprendizaje desde cero. */
  resetBrain() {
    this.rng = makeRng((Date.now() ^ 0x5bd1e995) & 0xffffff);
    this.evo = new Evolution(initGenome(this.rng), mutationScales(), this.rng);
    this.evo.denseCount = CPG_PARAMS;
    this.assist = CONFIG.assist.start;
    this.updateNnStage();
    this.history = [];
    this.terrainBest = TERRAINS.map(() => 0);
    this.unlocked = 0;
    this.assist = CONFIG.assist.start;
    this.assistStall = 0;
    if (this.terrainIdx !== 0) this.buildTerrain(0);
    this.restartAll(true);
  }

  // ------------------------------------------------------------------ interacción
  /** Empujón lateral/trasero aleatorio al personaje indicado. */
  push(slotIdx: number) {
    const s = this.slots[slotIdx];
    if (!s || s.state !== "run") return;
    const ang = this.rng() * Math.PI * 2;
    const k = CONFIG.pushImpulse;
    const imp = { x: Math.cos(ang) * k, y: 10, z: Math.sin(ang) * k };
    const chest = s.agent.bodies[1];
    chest.applyImpulse(imp, true);
  }

  /** El mejor personaje en este momento (el que más avanzó y sigue de pie). */
  updateFocus() {
    let best = -1;
    let bestX = -Infinity;
    for (let i = 0; i < this.slots.length; i++) {
      const s = this.slots[i];
      if (s.state !== "run") continue;
      const x = s.agent.px;
      const bonus = i === this.focus ? 0.8 : 0; // histéresis: evita saltos de cámara
      if (x + bonus > bestX) {
        bestX = x + bonus;
        best = i;
      }
    }
    if (best >= 0) this.focus = best;
    else if (this.focus >= this.slots.length) this.focus = 0;
    if (this.mode === "manual") this.focus = 0;
    return this.focus;
  }

  // ------------------------------------------------------------------ estadísticas
  stage(): { level: number; label: string } {
    const last = this.history.slice(-3);
    if (last.length === 0) return { level: 0, label: "Empezando…" };
    const bd = Math.max(...last.map((h) => h.bestDist));
    const mt = last.reduce((a, h) => a + h.meanTime, 0) / last.length;
    if (bd < 1 && mt < 2) return { level: 0, label: "Cayéndose al instante" };
    if (bd < 2.2) return { level: 1, label: "Gateando / tambaleándose" };
    if (bd < 5) return { level: 2, label: "Dando pasos" };
    if (bd < 9 || mt < 6) return { level: 3, label: "Caminando" };
    return { level: 4, label: "Caminata estable" };
  }

  snapshot() {
    const last = this.history[this.history.length - 1];
    let curBest = 0;
    let running = 0;
    for (const s of this.slots) {
      if (s.role === "es") curBest = Math.max(curBest, s.maxDist);
      if (s.state === "run") running++;
    }
    for (const r of this.results) if (r) curBest = Math.max(curBest, r.dist);
    const brain = this.slots.find((s) => s.role === "brain");
    return {
      gen: this.evo.gen + 1,
      evaluated: this.completed,
      pop: this.results.length,
      curBest,
      last,
      bestEver: Math.max(...this.terrainBest),
      terrainBest: this.terrainBest[this.terrainIdx],
      sigma: this.evo.sigma,
      eliteFit: this.evo.eliteFit,
      running,
      agents: this.slots.length,
      stage: this.stage(),
      brainDist: brain ? brain.maxDist : 0,
      brainTime: brain ? brain.t : 0,
      history: this.history,
      unlocked: this.unlocked,
      terrainIdx: this.terrainIdx,
      mode: this.mode,
      assist: this.assist,
    };
  }

  // ------------------------------------------------------------------ guardar / cargar
  exportBrain(): BrainFile {
    return {
      format: "ia-camina",
      version: 1,
      genomeSize: GENOME_SIZE,
      mean: Array.from(this.evo.mean, round5),
      elite: Array.from(this.evo.elite, round5),
      sigma: round5(this.evo.sigma),
      gen: this.evo.gen,
      eliteFit: round5(this.evo.eliteFit),
      history: this.history.slice(-300).map((h) => ({ ...h, bestDist: round5(h.bestDist), meanDist: round5(h.meanDist), bestFit: round5(h.bestFit), meanFit: round5(h.meanFit), meanTime: round5(h.meanTime) })),
      terrainBest: this.terrainBest.map(round5),
      unlocked: this.unlocked,
      assist: round5(this.assist),
      savedAt: new Date().toISOString(),
    };
  }

  importBrain(b: BrainFile) {
    if (!b || b.format !== "ia-camina" || b.genomeSize !== GENOME_SIZE || b.mean.length !== GENOME_SIZE) {
      throw new Error("Archivo de cerebro no compatible");
    }
    this.evo.load(b.mean, b.elite, clamp(b.sigma, 0.04, 1.2), b.gen, b.eliteFit);
    this.history = b.history ?? [];
    this.terrainBest = b.terrainBest ?? this.terrainBest;
    this.unlocked = clamp(b.unlocked ?? 0, 0, TERRAINS.length - 1);
    this.assist = clamp(b.assist ?? 0, 0, 1);
    this.assistStall = 0;
    this.updateNnStage();
    if (this.terrainIdx > this.unlocked) this.buildTerrain(this.unlocked);
    this.restartAll(true);
  }
}
