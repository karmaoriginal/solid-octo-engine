# 🦿 IA Camina — una IA que aprende a caminar (3D, en el navegador)

Humanoide con **19 grados de libertad** simulado con física real (Rapier). Empieza sin saber nada
(se retuerce y se cae) y mediante **evolución** aprende, ante tus ojos, a mantenerse en pie, dar pasos y caminar.
Funciona 100 % en el navegador (también en Android), sin servidor.

## Cómo ejecutarlo

```bash
npm install
npm run dev        # desarrollo  → http://localhost:5173
npm run build      # genera dist/index.html (un único archivo autocontenido, ~5 MB)
npm run preview    # sirve el build
```

`dist/index.html` es un solo archivo: se puede abrir directamente, subir a cualquier hosting estático o
copiar al celular. (Algunos navegadores bloquean Web Workers desde `file://`; si pasa, sírvelo con
`npm run preview` o súbelo a un hosting.)

Pruebas sin pantalla (opcional): `npx tsx scripts/headless.ts 200 24 20` entrena 200 generaciones en consola.

## Cómo se juega

| Control | Qué hace |
|---|---|
| 🧠 Entrenar / 🏃 Probar / 🎮 Manual | Entrena con muchos agentes · muestra el mejor cerebro · tú controlas las articulaciones (con el cerebro de la IA al lado para comparar) |
| x1 · x5 · x20 · x100 | Velocidad de simulación. x100 = "lo más rápido que permita el dispositivo" (el indicador de arriba muestra la velocidad real) |
| 🏔️ Terreno | Plano → Pendientes → Escalones → Obstáculos. Se desbloquean al aprender (ver abajo) |
| 🎥 Cámara | Atrás / Lateral / Frente / Aérea. Además: arrastra para girar, pellizca para acercar |
| 💥 Empujar | Empujón aleatorio al personaje en foco para probar su equilibrio |
| ☰ Menú | Guardar/cargar cerebro (archivo `.json` + copia en el dispositivo), nº de agentes, arnés, reiniciar |

Colores: **dorado** = líder, **verde** = los 3 mejores del momento, **azul** = resto, **gris** = caído.
Un hilo blanco tenue sobre cada personaje es el *arnés de equilibrio* (ver más abajo).

## Cómo funciona

**Cuerpo** (`src/sim/spec.ts`, `character.ts`): 13 segmentos con masa realista (pelvis, pecho, cabeza, muslos,
piernas, pies, brazos, antebrazos), fricción distinta en los pies, y 19 articulaciones de bisagra con límites de
ángulo y **motor con torque máximo** (cadera ×2 ejes, rodilla, tobillo ×2 ejes, columna ×2, cuello, hombro ×2 ejes,
codo — por lado). Las de 2 ejes se construyen con un cuerpo ligero intermedio.

**Observaciones** (60 valores): ángulos y velocidades de las 19 articulaciones, orientación de pelvis y pecho,
altura de la pelvis, velocidad lineal y angular, contacto de cada pie, fase del reloj interno y "vista" del
terreno por delante (50 cm y 1 m).

**Cerebro** (`policy.ts`): un oscilador central simétrico (el lado derecho es el izquierdo desfasado media vuelta,
lo que da pasos alternados) **+ una red neuronal** (60→10→19) que corrige el ritmo con las observaciones.
Salida = ángulo objetivo normalizado de cada motor.

**Recompensa** (`config.ts → reward`, `sim.ts → control`): avanzar hacia +X (solo cuenta si va erguido), estar
erguido y alto, pasos alternados hacia delante; castigos por esfuerzo muscular, movimientos espasmódicos,
desviarse de la dirección, arrastrar las piernas y caerse.

**Entrenamiento** (`es.ts`): estrategia evolutiva elitista con muestreo en espejo y mutación dispersa. Cada generación
evalúa 26 cerebros **en paralelo** (un mundo físico por agente); cuando un personaje se cae o acaba el tiempo se
reinicia solo con el siguiente candidato. La evaluación es determinista (cada candidato corre en un mundo nuevo), así
que las comparaciones son exactas. Aprende por etapas: primero el ritmo de la marcha (oscilador) y, cuando el arnés
ya baja, empieza a evolucionar la red de reflejos.

**Arnés de equilibrio (currículo)**: al comienzo un arnés virtual endereza el torso y sostiene parte del peso —
sin él un humanoide de 19 articulaciones no tiene gradiente de aprendizaje y solo se cae. Cuando el mejor cerebro
completa el episodio recorriendo distancia, el arnés **se reduce solo** (HUD: "Arnés %") hasta llegar a 0 %. Puedes
fijarlo a mano en ☰ Menú. Los terrenos nuevos se desbloquean al alcanzar cierta distancia en el anterior
**y** con el arnés ≤ 25 % (`CONFIG.unlockDistances`, `CONFIG.assist.unlockMax`). En 🏔️ Terreno hay un interruptor
"Desbloquear todos" para probar cualquier terreno de inmediato.

> ⏱️ El aprendizaje es real y no está "pregrabado": la rapidez depende de tu dispositivo. En un PC se ven pasos en
> pocos minutos; en un celular de gama media conviene dejarlo entrenando a x20/x100 y guardar el cerebro (☰ → Guardar).
> También se autoguarda en el dispositivo cada 25 generaciones.

**Rendimiento en celular**: toda la física corre en un **Web Worker** (la interfaz nunca se traba); si los FPS bajan
el motor reduce resolución, sombras y número de agentes automáticamente (mínimo 4). Por defecto 12 agentes en móvil, 24 en PC.

## Parámetros fáciles de ajustar

Todo está al inicio de `src/config.ts`: rigidez y amortiguación de los músculos, duración del episodio, tamaño de la
población, pesos de la recompensa, agentes por dispositivo, fuerza del empujón, distancias de desbloqueo y
parámetros del arnés. Torques y límites de cada articulación: `src/sim/spec.ts`.

## Estructura

```
src/config.ts        parámetros
src/sim/spec.ts      cuerpo: segmentos, articulaciones, límites, torques
src/sim/character.ts agente físico (Rapier): motores, lectura de estado, observaciones, arnés
src/sim/terrain.ts   perfiles de terreno (plano, pendientes, escalones, obstáculos)
src/sim/policy.ts    cerebro: oscilador + red neuronal
src/sim/es.ts        algoritmo evolutivo
src/sim/sim.ts       simulación, recompensas, generaciones, currículo, guardar/cargar
src/sim/worker.ts    Web Worker (física fuera del hilo de la interfaz)
src/render/scene.ts  escena three.js y cámara
src/engine.ts        puente worker ↔ escena, FPS adaptativos, entrada táctil
src/App.tsx, ui/*    interfaz táctil
```
